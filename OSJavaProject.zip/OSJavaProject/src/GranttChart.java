/*
import javax.swing.JLabel;
import javax.swing.JPanel;
public class GranttChart extends JPanel {

    private JPanel granttChart;

    public GranttChart(int n) {
        granttChart = new JPanel();

        for (int i = 0; i < n; i++) {
            JLabel jLabel = new JLabel();
            granttChart.add(jLabel);
        }
    }

    JPanel getPanel() {
        return granttChart;
    }

}
*/
