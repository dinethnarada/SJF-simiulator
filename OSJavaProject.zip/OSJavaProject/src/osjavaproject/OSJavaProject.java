/*
package osjavaproject;

import java.awt.Frame;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import osjavaproject.view.MainWindow;

public class OSJavaProject {

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
            Logger.getLogger(OSJavaProject.class.getName()).log(Level.SEVERE, null, ex);
        }

        MainWindow i = new MainWindow();
        i.setLocationRelativeTo(null);
        i.setExtendedState(Frame.MAXIMIZED_BOTH);
        i.setVisible(true);
    }

}
*/
