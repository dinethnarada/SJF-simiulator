
package osjavaproject.view;

import java.awt.Color;
import java.awt.Component;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

public class StatusColumnCellRenderer extends DefaultTableCellRenderer {

    private ArrayList<Color> colors;

    public StatusColumnCellRenderer() {
        colors = new ArrayList<>();
    }

    
    
    public void setColor(Color color) {
        colors.add(color);
    }

    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int col) {

        JLabel l = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, col);
        l.setBackground(colors.get(row));
        return l;

    }
}
