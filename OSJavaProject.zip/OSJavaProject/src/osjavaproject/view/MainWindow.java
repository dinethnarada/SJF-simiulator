package osjavaproject.view;

import java.awt.Color;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

public class MainWindow extends javax.swing.JFrame {

    private final DefaultTableModel processDetailTableModel;
    private final GranttCanvas canvas;
    private int stop = 0;
    private final Color[] colors = {Color.RED, Color.BLUE, Color.ORANGE, Color.GREEN, Color.YELLOW, Color.CYAN, Color.PINK, Color.MAGENTA, Color.BLACK, Color.GRAY};
    private final StatusColumnCellRenderer statusColumnCellRenderer;

   
    public MainWindow() {
        initComponents();
        processDetailTableModel = (DefaultTableModel) processDetailTable.getModel();
        processDetailTable.setCellSelectionEnabled(true);

        statusColumnCellRenderer = new StatusColumnCellRenderer();

   

        canvas = new GranttCanvas();
        canvas.setVisible(true);
        canvas.setSize(granttChartPanel.getSize());
        granttChartPanel.add(canvas);

        TableColumn column = processDetailTable.getColumnModel().getColumn(0);
        column.setCellRenderer(statusColumnCellRenderer);

    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        processNameText = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        burstTimeText = new javax.swing.JTextField();
        addButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        processDetailTable = new javax.swing.JTable();
        startButton = new javax.swing.JButton();
        stopButton = new javax.swing.JButton();
        restartButton = new javax.swing.JButton();
        sliderValueLabel = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        averageWaitingTimeLabel = new javax.swing.JLabel();
        averageTurnaroundTimeLabel = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        granttChartPanel = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(179, 247, 139));

        jPanel1.setBorder(new javax.swing.border.MatteBorder(null));

        jLabel2.setText("Process-name");

        processNameText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                processNameTextActionPerformed(evt);
            }
        });

        jLabel3.setText("Burst Time");

        burstTimeText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                burstTimeTextActionPerformed(evt);
            }
        });
        burstTimeText.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                burstTimeTextKeyPressed(evt);
            }
        });

        addButton.setText("Add Process");
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });

        processDetailTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Process Color", "Process Name", "Burst Time", "Waiting Time", "Turnaround Time", "Percentage"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(processDetailTable);

        startButton.setText("Start Simulation");
        startButton.setEnabled(false);
        startButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                startButtonActionPerformed(evt);
            }
        });

        stopButton.setText("Stop Simulation");
        stopButton.setEnabled(false);
        stopButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stopButtonActionPerformed(evt);
            }
        });

        restartButton.setText("Restart");
        restartButton.setEnabled(false);
        restartButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                restartButtonActionPerformed(evt);
            }
        });

        sliderValueLabel.setText(" ");

        jLabel1.setText("     SJF SIMIULATOR");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(startButton, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(stopButton, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(62, 62, 62)
                        .addComponent(sliderValueLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(restartButton, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(burstTimeText))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(processNameText, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                        .addComponent(addButton, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(processNameText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(burstTimeText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(addButton, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 209, Short.MAX_VALUE)
                .addGap(39, 39, 39)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(startButton)
                    .addComponent(stopButton)
                    .addComponent(restartButton)
                    .addComponent(sliderValueLabel))
                .addContainerGap())
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Result"));

        jLabel5.setText("Average Waiting Time");

        jLabel6.setText("Average Turnaround Time");

        averageWaitingTimeLabel.setText(" ");

        averageTurnaroundTimeLabel.setText(" ");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(averageTurnaroundTimeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(averageWaitingTimeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addGap(0, 120, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(averageWaitingTimeLabel)
                .addGap(24, 24, 24)
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addComponent(averageTurnaroundTimeLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Grantt Chart"));

        javax.swing.GroupLayout granttChartPanelLayout = new javax.swing.GroupLayout(granttChartPanel);
        granttChartPanel.setLayout(granttChartPanelLayout);
        granttChartPanelLayout.setHorizontalGroup(
            granttChartPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        granttChartPanelLayout.setVerticalGroup(
            granttChartPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 175, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(granttChartPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(granttChartPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void restartButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_restartButtonActionPerformed
        startButtonActionPerformed(null);
    }//GEN-LAST:event_restartButtonActionPerformed

    private void stopButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stopButtonActionPerformed
        stop = 1;
    }//GEN-LAST:event_stopButtonActionPerformed

    private void startButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_startButtonActionPerformed
        if (processDetailTable.getRowCount() > 0) {

            int processCount = processDetailTable.getRowCount(); // number of process that we input
            
            int process[] = new int[processCount]; //inialize a number for a each process
            int[] burst_time = new int[processCount]; //get burst times and append to the array
            int[] waiting_time = new int[processCount]; // get waiting times and append to the array
            int[] turnaround_time = new int[processCount]; //to calculate turnaround time 
            
            String[] process_name = new String[processCount];

            for (int i = 0; i < processDetailTable.getRowCount(); i++) {
                process_name[i] = (String)processDetailTable.getValueAt(i,1);
                burst_time[i] =  (int) processDetailTable.getValueAt(i, 2);
                process[i] = i;
                
            }

            startButton.setEnabled(false);
            stopButton.setEnabled(true);
            restartButton.setEnabled(false);

            new Thread(new Runnable() {

                @Override
                public void run() {
                    int x = 10;
                    Color color;
                    String pname;
                    boolean a = true;
                    int temp, ttotal = 0, wtotal=0 , b_total = 0;

                    for (int i = 0; i < processCount-1; i++) {
                        for(int j=i+1 ; j < processCount ; j++) {
                            if(burst_time[i] > burst_time[j])
                            {
                                temp = burst_time[i];
                                burst_time[i] = burst_time[j];
                                burst_time[j] = temp;
                                temp = process[i];
                                process[i] = process[j];
                                process[j] = temp;
                                color = colors[i];
                                colors[i] = colors[j];
                                colors[j] = color;
                                pname = process_name[i];
                                process_name[i] = process_name[j];
                                process_name[j] = pname;
                            }
                        }
                    }

                    waiting_time[0] = 0;
                    turnaround_time[0] = waiting_time[0]+burst_time[0];
                    ttotal += turnaround_time[0];

                    for(int i=1; i < processCount ; i++) {
                        waiting_time[i] = waiting_time[i-1]+burst_time[i-1];
                        wtotal = wtotal + waiting_time[i];
                        turnaround_time[i] = waiting_time[i]+burst_time[i];
                        ttotal = ttotal + turnaround_time[i];

                    }

                    /*
                    Draw on canvas
                    */
                    for (int i=0; i< processCount;i++){
                        if (a) {
                            canvas.reset();
                            a = false;
                        }
                        canvas.addSlice(canvas.getGraphics(), colors[i% 10], x,10,10*burst_time[i],100);
                        b_total += 10*burst_time[i];
                        x = 10 + b_total;
                        /*if(i==0){
                            System.out.println("ProcessName\tBurstTime\tWaitingTime\tTurnaroundTime");
                        }
                        System.out.println("\t"+process_name[i]+"\t\t"+burst_time[i]+"\t\t"+waiting_time[i]+"\t\t"+turnaround_time[i]);
                        */
                        Color p_color = colors[i];
                        processDetailTable.setValueAt(i+1,i,0);
                        processDetailTable.setValueAt(process_name[i],i,1);
                        processDetailTable.setValueAt(burst_time[i],i,2);
                        processDetailTable.setValueAt(waiting_time[i],i,3);
                        processDetailTable.setValueAt(turnaround_time[i],i,4);
                        double per = ((burst_time[i])/(double)burst_time[i])*100;
                        processDetailTable.setValueAt((String.format("%.2f",per)+"%"),i,5);
                        try{
                            Thread.sleep(1000);
                        }catch(InterruptedException ex){
                            Logger.getLogger(MainWindow.class.getName()).log(Level.SEVERE,null,ex);
                        }
                        if (stop == 1) {
                            stop = 0;
                            break;
                        }
                    }

                    restartButton.setEnabled(true);
                    stopButton.setEnabled(false);
                    float wavg = ((float)wtotal/processCount);
                    float tavg = ((float)ttotal/processCount);
                    averageWaitingTimeLabel.setText((String.format("%.2f", wavg))+ "");
                    averageTurnaroundTimeLabel.setText((String.format("%.2f", tavg)) + "");
                    //System.out.println("Average waiting time:" + ((String.format("%.2f", wavg))));
                    //System.out.println("Average Turnaround time:" + ((String.format("%.2f", tavg))));
                }

            }).start();

        }
    }//GEN-LAST:event_startButtonActionPerformed

    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed

        if (!"".equals(processNameText.getText()) && !"".equals(burstTimeText.getText())) {
            String processName = processNameText.getText();
            int burstTime = Integer.parseInt(burstTimeText.getText());

            Object row[] = {null, processName, burstTime, 0, 0};
            processDetailTableModel.addRow(row);

            int colorNumber = (processDetailTable.getRowCount()) % 10;

            //column.setCellRenderer(new CellColorRenderer(colors[colorNumber], stop, stop));
            int rowMy = processDetailTable.getRowCount() - 1;
            statusColumnCellRenderer.setColor(colors[colorNumber - 1]);
            processNameText.setText(null);
            burstTimeText.setText(null);

            processNameText.requestFocus();
            startButton.setEnabled(true);
        }
    }//GEN-LAST:event_addButtonActionPerformed

    private void burstTimeTextKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_burstTimeTextKeyPressed

        burstTimeText.setEditable(true);
    }//GEN-LAST:event_burstTimeTextKeyPressed

    private void burstTimeTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_burstTimeTextActionPerformed
        addButtonActionPerformed(null);
    }//GEN-LAST:event_burstTimeTextActionPerformed

    private void processNameTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_processNameTextActionPerformed
        burstTimeText.requestFocus();
    }//GEN-LAST:event_processNameTextActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new MainWindow().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addButton;
    private javax.swing.JLabel averageTurnaroundTimeLabel;
    private javax.swing.JLabel averageWaitingTimeLabel;
    private javax.swing.JTextField burstTimeText;
    private javax.swing.JPanel granttChartPanel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable processDetailTable;
    private javax.swing.JTextField processNameText;
    private javax.swing.JButton restartButton;
    private javax.swing.JLabel sliderValueLabel;
    private javax.swing.JButton startButton;
    private javax.swing.JButton stopButton;
    // End of variables declaration//GEN-END:variables
}
