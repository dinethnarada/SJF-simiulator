
package osjavaproject.view;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

public class GranttCanvas extends Canvas {

    private ArrayList<Slice> slices = new ArrayList<>();

    @Override
    public void paint(Graphics g) {
        super.paint(g); //To change body of generated methods, choose Tools | Templates.

        for (Slice slice : slices) {
            g.setColor(slice.getColor());
            g.fillRect(slice.getX(), slice.getY(), slice.getWidth(), slice.getHeight());
        }
    }

    public void addSlice(Graphics g, Color color, int x, int y, int width, int height) {
        Slice slice = new Slice(color, x, y, width, height);
        slices.add(slice);

        paint(g);
    }

    void reset() {
        slices = new ArrayList<>();
    }

}
