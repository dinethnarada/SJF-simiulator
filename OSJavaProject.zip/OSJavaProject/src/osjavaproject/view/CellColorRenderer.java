
package osjavaproject.view;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

public class CellColorRenderer extends DefaultTableCellRenderer {

    Color c;
    int row, col;

    CellColorRenderer(Color color, int row, int col) {
        this.c = color;
        this.row = row;
        this.col = col;
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        JLabel jLabel = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, this.row, this.col);
        if (row == this.row && column == this.col) {
            jLabel.setBackground(c);
        }
        return jLabel;
    }

}
